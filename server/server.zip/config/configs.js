module.exports = {
    port: 3000,
    protocol: 'http',
    host: 'localhost',
    mongoUrl: 'mongodb://admin:admin123456@ds159185.mlab.com:59185/task',
    jwt_key: 'erik'
};
