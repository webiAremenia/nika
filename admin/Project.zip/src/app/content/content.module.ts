import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ContentRoutingModule} from './content-routing.module';
import { TestUserDataComponent } from './test-user-data/test-user-data.component';
import {NgZorroAntdModule} from "ng-zorro-antd";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {ReactiveFormsModule} from "@angular/forms";
import {ContentComponent} from "./content.component";
import { PostsListComponent } from './posts-list/posts-list.component';
import { ChangePostComponent } from './change-post/change-post.component';
import { AddPostComponent } from './add-post/add-post.component';

@NgModule({
  declarations: [
    TestUserDataComponent,
    ContentComponent,
    PostsListComponent,
    ChangePostComponent,
    AddPostComponent
  ],
  imports: [
    CommonModule,
    ContentRoutingModule,
    ReactiveFormsModule,
    NgZorroAntdModule,
    BrowserAnimationsModule
  ]
})
export class ContentModule { }
