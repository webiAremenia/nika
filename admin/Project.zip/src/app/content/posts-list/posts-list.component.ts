import { Component, OnInit } from '@angular/core';
import {PostsService} from "../../shared/services/posts.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-posts-list',
  templateUrl: './posts-list.component.html',
  styleUrls: ['./posts-list.component.css']
})
export class PostsListComponent implements OnInit {
  posts: any = [];
  sortName: string | null = null;
  sortValue: string | null = null;
  searchAddress: string;
  listOfName = [ { text: 'Joe', value: 'Joe' }, { text: 'Jim', value: 'Jim' } ];
  listOfAddress = [ { text: 'London', value: 'London' }, { text: 'Sidney', value: 'Sidney' } ];
  listOfSearchName: string[] = [];
  constructor(private service: PostsService, private router: Router) {
  }

  ngOnInit() {
    this.service.getPosts().subscribe((data) => {
      this.posts = data;
    })
  }

  edit(post) {
    this.service.candidatePost = post;
    this.router.navigate(['content','changePost'])
  }

  delete(post) {
    this.service.candidatePost = post;
  }

  addPost() {
    this.router.navigate(['content','addPost'])
  }

}
