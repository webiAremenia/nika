import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ContentComponent} from "./content.component";
import {TestUserDataComponent} from "./test-user-data/test-user-data.component";
import {PostsListComponent} from "./posts-list/posts-list.component";
import {ChangePostComponent} from "./change-post/change-post.component";
import {AddPostComponent} from "./add-post/add-post.component";

const routes: Routes = [
  {path: 'content', component: ContentComponent, children: [
      {path: 'post', component: PostsListComponent},
      {path: 'changePost', component: ChangePostComponent},
      {path: 'addPost', component: AddPostComponent},
      {path: 'block', component: TestUserDataComponent},
      {path: 'menu', component: TestUserDataComponent},
      {path: 'media', component: TestUserDataComponent},
      {path: 'portfolio', component: TestUserDataComponent},
      {path: '**', redirectTo: 'post', pathMatch: 'full'}
    ]},
  {path: '**', redirectTo: '/content', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ContentRoutingModule { }
