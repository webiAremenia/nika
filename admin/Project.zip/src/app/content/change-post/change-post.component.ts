import { Component, OnInit } from '@angular/core';
import {PostsService} from "../../shared/services/posts.service";

@Component({
  selector: 'app-change-post',
  templateUrl: './change-post.component.html',
  styleUrls: ['./change-post.component.css']
})
export class ChangePostComponent implements OnInit {

  constructor(private service: PostsService) { }

  ngOnInit() {
    console.log(this.service.candidatePost)
  }

}
