import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slider-preview',
  templateUrl: './slider-preview.component.html',
  styleUrls: ['./slider-preview.component.css']
})
export class SliderPreviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
