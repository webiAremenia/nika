import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-slider',
  templateUrl: './change-slider.component.html',
  styleUrls: ['./change-slider.component.css']
})
export class ChangeSliderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
