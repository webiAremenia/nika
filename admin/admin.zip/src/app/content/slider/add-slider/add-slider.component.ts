import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-slider',
  templateUrl: './add-slider.component.html',
  styleUrls: ['./add-slider.component.css']
})
export class AddSliderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
