import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sliders-list',
  templateUrl: './sliders-list.component.html',
  styleUrls: ['./sliders-list.component.css']
})
export class SlidersListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
